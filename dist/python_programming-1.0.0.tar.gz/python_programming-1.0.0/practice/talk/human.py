from practice.tools import biile

def sing():
    return 'sing'

def cry():
    return biile.say_twice("cry")