from practice.tools import biile

def sing():
    return 'ngkiahwiojsilngadlg'

def cry():
    return biile.say_twice("cdsakhjngbikoperdjaqhipdrjphj")