from setuptools import setup


setup(
    name='python_programming',
    version='1.0.0',
    packages=['practice', 'practice.talk', 'practice.tools'],
    url='',
    license='Free',
    author='kdoi',
    author_email='',
    description='sample package'
)